Verified rejected (c,z) pairs for s1 recovery (D2, known key).
c_pred (N,256) int8 {-1,0,1}: recovered challenge (Algorithm-5 + output-HW verify).
z_pred_val int64 in {+-131072,+-131071/3}: boundary z at (poly_l,coeff_i); k=poly_l*256+coeff_i.
Selection uses only SCA confidences (conf<=10, z_conf>=0.99); truth columns are for audit.
pair_ok = c_pred==c_true AND z_pred==z_true (achieved purity reported in summary).
